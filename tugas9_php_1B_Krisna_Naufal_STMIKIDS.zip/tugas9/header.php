  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center">
    <div class="container" data-aos="zoom-in" data-aos-delay="100">
      <h1>Krisna Naufal</h1>
      <p>I'm <span class="typed" data-typed-items="Freelancer,Active College Student"></span></p>
      <div class="social-links">
        <a href="https://www.facebook.com/profile.php?id=100005155325927" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/krsnabiru_/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://krisnanaufal240601.wordpress.com/" class="wordpress"><i class="bx bxl-wordpress"></i></a>
      </div>
    </div>
  </section><!-- End Hero -->
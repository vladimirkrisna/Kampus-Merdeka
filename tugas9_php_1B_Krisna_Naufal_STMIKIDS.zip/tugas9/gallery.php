<section id="references" class="references">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Gallery</h2>
        </div>

        <div class="row">
          <div class="alert alert-primary" role="alert">
          <table align="center" cellpadding="20px">
            <tr>
              <td>
              <img src="assets/img/dicoding.jpeg" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">Sertif Dicoding</h5>
                    <p class="card-text">Bukti pembelajaran informal</p>
                </div>
              </td>
              <td>
              <img src="assets/img/alterra.jpeg" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">Sertif Alterra Academy</h5>
                    <p class="card-text">Bukti pembelajaran informal</p>
                </div>
              </td>
            </tr>
          </table>
        </div>
        </div>

      </div>
    </section><!-- End Services Section -->
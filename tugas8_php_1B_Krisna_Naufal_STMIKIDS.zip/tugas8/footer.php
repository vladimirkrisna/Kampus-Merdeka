<div class="row">
    <div class="col-md-12">
        <!---------------awal konten-------------------->
        <div class="alert alert-light" role="alert" align="center">
            Develop By: Krisna@2022 Kampus Merdeka
        </div>
        <!---------------akhir konten-------------------->
    </div>
</div>
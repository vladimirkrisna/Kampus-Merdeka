<div class="row">
    <div class="col-md-6">
    <img src="images/dicoding.jpeg" class="card-img-top">
    <div class="card-body">
        <h5 class="card-title">Sertif Dicoding</h5>
        <p class="card-text">Bukti pembelajaran informal</p>
    </div>
    </div>

    <div class="col-md-6">
    <img src="images/alterra.jpeg" class="card-img-top">
    <div class="card-body">
        <h5 class="card-title">Sertif Alterra Academy</h5>
        <p class="card-text">Bukti pembelajaran informal</p>
    </div>
    </div>
</div>
<div class="alert alert-light" role="alert">
<figure class="text-center">
    <blockquote class="blockquote">
        <p>"Habis bangun tidur, makan, tidur, bangun lagi, makan, tidur lagi. Seumur hidupku tanpa istirahat. Aku butuh istirahat dalam keseharianku."</p>
    </blockquote>
    <figcaption class="blockquote-footer">
        Patrick Star
    </figcaption>
</figure>
</div>